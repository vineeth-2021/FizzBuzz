using FizzBuzz.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace FizzBuzz.TestProject
{
    public class UnitTest1
    {
        
        [Fact]
        public void DivideBy_3_or_5_InvalidInput()
        {
            FizzBuzzService fizzBuzzService = new FizzBuzzService();
            //Arrange
            List<String> expected = new List<String>();
            expected.Add("Invalid item");
            //Act
            List<String> result = new List<string>();
            foreach (var item in fizzBuzzService.Multipleof_3_or_5(" "))
                result.Add(item);

            //Assert
            Assert.True(expected.SequenceEqual(result));
        }
        [Fact]
        public void DivideBy_3_or_5_DivideOnly_By_3()
        {

            //Arrange
            FizzBuzzService fizzBuzzService = new FizzBuzzService();
            List<String> expected = new List<String>();
            expected.Add("Fizz");
            //Act
            List<String> result = new List<string>();
            foreach (var item in fizzBuzzService.Multipleof_3_or_5("6"))
                result.Add(item);


            //Assert
            Assert.True(expected.SequenceEqual(result));
        }
        [Fact]
        public void DivideBy_3_or_5_DivideOnly_By_5()
        {

            //Arrange
            FizzBuzzService fizzBuzzService = new FizzBuzzService();
            List<String> expected = new List<String>();
            expected.Add("Buzz");
            //Act
            List<String> result = new List<string>();
            foreach (var item in fizzBuzzService.Multipleof_3_or_5("5"))
                result.Add(item);


            //Assert
            Assert.True(expected.SequenceEqual(result));
        }
        [Fact]
        public void DivideBy_3_or_5_DivideOnly_By_3_AND_5()
        {

            //Arrange
            FizzBuzzService fizzBuzzService = new FizzBuzzService();
            List<String> expected = new List<String>();
            expected.Add("FizzBuzz");
            //Act
            List<String> result = new List<string>();
            foreach (var item in fizzBuzzService.Multipleof_3_or_5("15"))
                result.Add(item);


            //Assert
            Assert.True(expected.SequenceEqual(result));
        }
        [Fact]
        public void DivideBy_3_or_5_Not_DivideOnly_By_3_AND_5()
        {

            //Arrange
            FizzBuzzService fizzBuzzService = new FizzBuzzService();
            List<String> expected = new List<String>();
            expected.Add("Divided 1 by 3");
            expected.Add("Divided 1 by 5");
            //Act
            List<String> result = new List<string>();
            foreach (var item in fizzBuzzService.Multipleof_3_or_5("1"))
                result.Add(item);


            //Assert
            Assert.True(expected.SequenceEqual(result));
        }
    }
}
